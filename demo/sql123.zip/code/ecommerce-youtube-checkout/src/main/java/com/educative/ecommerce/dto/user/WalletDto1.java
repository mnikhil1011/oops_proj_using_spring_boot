package com.educative.ecommerce.dto.user;

public class WalletDto1 {

    private Long card;
    private Long amt;

    public WalletDto1() {
    }

    public WalletDto1(Long card, Long amt) {
        this.card = card;
        this.amt = amt;
    }

    public Long getCard() {
        return card;
    }

    public void setCard(Long card) {
        this.card = card;
    }

    public Long getAmt() {
        return amt;
    }

    public void setAmt(Long amt) {
        this.amt = amt;
    }
}
