package com.example.demo.exceptions;

public class NormalException extends IllegalArgumentException{

    public NormalException(String msg)
    {
        super(msg);
    }

}
